// export const products = [
//   { id: 1, name: "Laptop", category: "Electronics", price: 1200 },
//   { id: 2, name: "T-Shirt", category: "Clothing", price: 25 },
//   { id: 3, name: "The Great Gatsby", category: "Books", price: 15 },
//   { id: 4, name: "Smartphone", category: "Electronics", price: 800 },
//   { id: 5, name: "Jeans", category: "Clothing", price: 50 },
//   { id: 6, name: "Sapiens", category: "Books", price: 20 },

//   { id: 7, name: "Bluetooth Headphones", category: "Electronics", price: 150 },
//   { id: 8, name: "Hoodie", category: "Clothing", price: 40 },
//   { id: 9, name: "Atomic Habits", category: "Books", price: 18 },
//   { id: 10, name: "Wireless Keyboard", category: "Electronics", price: 60 },

//   { id: 11, name: "Jacket", category: "Clothing", price: 75 },
//   { id: 12, name: "Rich Dad Poor Dad", category: "Books", price: 12 },
//   { id: 13, name: "4K Monitor", category: "Electronics", price: 350 },
//   { id: 14, name: "Sweatpants", category: "Clothing", price: 35 },
//   { id: 15, name: "Deep Work", category: "Books", price: 16 },

//   { id: 16, name: "Gaming Mouse", category: "Electronics", price: 45 },
//   { id: 17, name: "Formal Shirt", category: "Clothing", price: 30 },
//   { id: 18, name: "Learn Python the Hard Way", category: "Books", price: 22 },
//   { id: 19, name: "Smartwatch", category: "Electronics", price: 250 },
//   { id: 20, name: "Track Pants", category: "Clothing", price: 28 }
// ];



export const products = [
  { 
    id: 1, 
    name: "Laptop", 
    category: "Electronics", 
    price: 1200,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8"
  },
  { 
    id: 2, 
    name: "T-Shirt", 
    category: "Clothing", 
    price: 25,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab"
  },
  { 
    id: 3, 
    name: "The Great Gatsby", 
    category: "Books", 
    price: 15,
    image: "https://assets.playbill.com/playbill-covers/The-Great-Gatsby-Playbill-2024-03-29_Web.jpg"
  },
  { 
    id: 4, 
    name: "Smartphone", 
    category: "Electronics", 
    price: 800,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9"
  },
  { 
    id: 5, 
    name: "Jeans", 
    category: "Clothing", 
    price: 50,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmBVr6RuVkTxUBPtuXg795gqmLspn2iH8flA&s"
  },
  { 
    id: 6, 
    name: "Sapiens", 
    category: "Books", 
    price: 20,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnms1h7r7R9KDUmpgLXNALd1TTfCV5bm775A&s"
  },

  { 
    id: 7, 
    name: "Bluetooth Headphones", 
    category: "Electronics", 
    price: 150,
    image: "https://5.imimg.com/data5/JS/AW/BL/SELLER-65538252/sound-one-bt-06-bluetooth-headphones-black-.jpg"
  },
  { 
    id: 8, 
    name: "Hoodie", 
    category: "Clothing", 
    price: 40,
    image: "https://coveritup.com/cdn/shop/products/redhoodie.jpg?v=1658311476&width=2048"
  },
  { 
    id: 9, 
    name: "Atomic Habits", 
    category: "Books", 
    price: 18,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfCwhL_DW2exO75b51X0OiaYRyzz--qCaI9w&s"
  },
  { 
    id: 10, 
    name: "Wireless Keyboard", 
    category: "Electronics", 
    price: 60,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSmjPHqtqQl8HMN_g5Q7aKV6jlj9nrwJTWpw&s"
  },

  { 
    id: 11, 
    name: "Jacket", 
    category: "Clothing", 
    price: 75,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvqNK5FYxIt-Nk2ucLFa68z3aD1Fya2njG4A&s"
  },
  { 
    id: 12, 
    name: "Rich Dad Poor Dad", 
    category: "Books", 
    price: 12,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7KXtNbOrToNO4cFk7tKRial2oeIO2BWwtmg&s"
  },
  { 
    id: 13, 
    name: "4K Monitor", 
    category: "Electronics", 
    price: 350,
    image: "https://i.dell.com/is/image/DellContent/content/dam/ss2/product-images/dell-client-products/peripherals/monitors/s-series/s2725qc/media-gallery/monitor-s2725qc-gray-gallery-1.psd?fmt=png-alpha&pscan=auto&scl=1&hei=320&wid=355&qlt=100,1&resMode=sharp2&size=355,320&chrss=full"
  },
  { 
    id: 14, 
    name: "Sweatpants", 
    category: "Clothing", 
    price: 35,
    image: "https://5.imimg.com/data5/IP/UR/MY-23656050/tight-fit-swat-pants-500x500.jpg"
  },
  { 
    id: 15, 
    name: "Deep Work", 
    category: "Books", 
    price: 16,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRv40aQc2wicZob0hUSg-5cBaWWtQYdsJBstg&s"
  },

  { 
    id: 16, 
    name: "Gaming Mouse", 
    category: "Electronics", 
    price: 45,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyeDgDX2531eXcVExFIdULXiUofwqQTo_wsg&s"
  },
  { 
    id: 17, 
    name: "Formal Shirt", 
    category: "Clothing", 
    price: 30,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR98VtBv9kXSJWqjH5Aaiy3DpYRLir0AvdBuQ&s"
  },
  { 
    id: 18, 
    name: "Learn Python the Hard Way", 
    category: "Books", 
    price: 22,
    image: "https://m.media-amazon.com/images/I/51DbqUNZudL._AC_UC200,200_CACC,200,200_QL85_.jpg?aicid=community-reviews"
  },
  { 
    id: 19, 
    name: "Smartwatch", 
    category: "Electronics", 
    price: 250,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYQ0V0q1StfCwaoMSEUi54QOXTHWV6t9kHJw&s"
  },
  { 
    id: 20, 
    name: "Track Pants", 
    category: "Clothing", 
    price: 28,
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR59Vg_1qeaFMIP5PPss7OZsVZRJ0f0WlwkJA&s"
  }
];
