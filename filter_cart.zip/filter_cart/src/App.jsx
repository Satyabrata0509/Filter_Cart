import { useState } from "react";
import FilterBar from "./components/FilterBar";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";
import {products} from "./data/products";

export default function App() {
  const [category, setCategory] = useState("All");
  const [cart, setCart] = useState({});

  function addToCart(product) {
    setCart((prev) => {
      const copy = { ...prev };
      if (!copy[product.id]) {
        copy[product.id] = { ...product, qty: 1 };
      } else {
        copy[product.id].qty += 1;
      }
      return copy;
    });
  }

  function removeFromCart(productId) {
    setCart((prev) => {
      const copy = { ...prev };
      if (!copy[productId]) return prev;
      delete copy[productId];
      return copy;
    });
  }

  function updateQty(productId, qty) {
    setCart((prev) => {
      const copy = { ...prev };
      if (!copy[productId]) return prev;

      if (qty <= 0) delete copy[productId];
      else copy[productId].qty = qty;

      return copy;
    });
  }

  const filtered =
    category === "All"
      ? products
      : products.filter((p) => p.category === category);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Dynamic Product Filter & Cart</h1>
          <div className="text-sm text-gray-600">
            Simple front-end assignment
          </div>
        </header>

        <main className="grid lg:grid-cols-3 gap-6">
          <section className="lg:col-span-2">
            <FilterBar
              categories={[
                "All",
                ...Array.from(new Set(products.map((p) => p.category))),
              ]}
              selected={category}
              onSelect={setCategory}
            />

            <ProductList products={filtered} onAdd={addToCart} />
          </section>

          <aside>
            <Cart
              items={Object.values(cart)}
              onRemove={removeFromCart}
              onUpdateQty={updateQty}
            />
          </aside>
        </main>
      </div>
    </div>
  );
}
