export function formatCurrency(n) {
  return n.toLocaleString("en-IN", { style: "currency", currency: "INR" });
}
