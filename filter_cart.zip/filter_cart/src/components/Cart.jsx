// export default function Cart({ items, onRemove, onUpdateQty }) {
//   const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);

//   return (
//     <div className="bg-white p-5 shadow rounded-lg">
//       <h2 className="text-xl font-bold mb-4">Cart</h2>

//       {items.length === 0 ? (
//         <p className="text-gray-500">Cart is empty.</p>
//       ) : (
//         <div className="space-y-4">
//           {items.map((item) => (
//             <div
//               key={item.id}
//               className="flex justify-between items-center border-b pb-3"
//             >
//               <div>
//                 <h3 className="font-semibold">{item.name}</h3>
//                 <p className="text-sm text-gray-500">
//                   ₹{item.price} × {item.qty}
//                 </p>

//                 <div className="flex gap-2 mt-2">
//                   <button
//                     onClick={() => onUpdateQty(item.id, item.qty - 1)}
//                     className="px-2 py-1 border rounded"
//                   >
//                     -
//                   </button>
//                   <button
//                     onClick={() => onUpdateQty(item.id, item.qty + 1)}
//                     className="px-2 py-1 border rounded"
//                   >
//                     +
//                   </button>
//                 </div>
//               </div>

//               <button
//                 onClick={() => onRemove(item.id)}
//                 className="text-red-600"
//               >
//                 Remove
//               </button>
//             </div>
//           ))}

//           <div className="font-bold text-right text-lg">
//             Total: ₹{total.toFixed(2)}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// }



export default function Cart({ items, onRemove, onUpdateQty }) {
  const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);

  return (
    <div className="bg-white p-5 shadow rounded-lg">
      <h2 className="text-xl font-bold mb-4">Cart</h2>

      {items.length === 0 ? (
        <p className="text-gray-500">Cart is empty.</p>
      ) : (
        <div className="space-y-4">
          {items.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between border-b pb-3"
            >
              {/* Image */}
              <img
                src={item.image}
                alt={item.name}
                className="w-16 h-16 object-cover rounded-md mr-3"
              />

              {/* Details */}
              <div className="flex-1">
                <h3 className="font-semibold">{item.name}</h3>
                <p className="text-sm text-gray-500">
                  ₹{item.price} × {item.qty}
                </p>

                <div className="flex gap-2 mt-2">
                  <button
                    onClick={() => onUpdateQty(item.id, item.qty - 1)}
                    className="px-2 py-1 border rounded"
                  >
                    -
                  </button>
                  <button
                    onClick={() => onUpdateQty(item.id, item.qty + 1)}
                    className="px-2 py-1 border rounded"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Remove */}
              <button
                onClick={() => onRemove(item.id)}
                className="text-red-600 ml-4"
              >
                Remove
              </button>
            </div>
          ))}

          <div className="font-bold text-right text-lg">
            Total: ₹{total.toFixed(2)}
          </div>
        </div>
      )}
    </div>
  );
}
