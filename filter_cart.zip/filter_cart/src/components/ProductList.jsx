// export default function ProductList({ products, onAdd }) {
//   return (
//     <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
//       {products.map((product) => (
//         <div
//           key={product.id}
//           className="border p-4 rounded-lg bg-white shadow-sm"
//         >
//           <h2 className="font-semibold text-lg">{product.name}</h2>
//           <p className="text-sm text-gray-600">{product.category}</p>

//           <div className="mt-3 flex justify-between items-center">
//             <span className="font-bold text-blue-700">₹{product.price}</span>
//             <button
//               className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700"
//               onClick={() => onAdd(product)}
//             >
//               Add
//             </button>
//           </div>
//         </div>
//       ))}
//     </div>
//   );
// }



export default function ProductList({ products, onAdd }) {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {products.map((product) => (
        <div
          key={product.id}
          className="border p-4 rounded-lg bg-white shadow-sm"
        >

          {/* Product Image */}
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-40 object-cover rounded-md mb-3"
          />

          <h2 className="font-semibold text-lg">{product.name}</h2>
          <p className="text-sm text-gray-600">{product.category}</p>

          <div className="mt-3 flex justify-between items-center">
            <span className="font-bold text-blue-700">₹{product.price}</span>
            <button
              className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700"
              onClick={() => onAdd(product)}
            >
              Add
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
